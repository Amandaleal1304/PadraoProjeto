
package abstractfactoryautomovel;


public interface Automovel {
 void exibirInfo();
 void entrar();
 void ligarMotor();
 void furarPneu();
}
