
package abstractfactoryautomovel;

public interface Fabrica {
    Automovel criarAutomovel();
}
